const list = {
    init() {
        console.log('list js 入口文件');
    }
}

export default list;