/**
 * 导入组件依赖的js文件
 */
import list from '../../components/list/list';

list.init();